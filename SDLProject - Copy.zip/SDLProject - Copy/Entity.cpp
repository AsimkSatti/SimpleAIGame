#include "Entity.h"

Entity::Entity()
{
	entityType = PLATFORM;
	isStatic = true;
	isActive = true;
	position = glm::vec3(0);
	speed = 0;
	width = 1;
	height = 1;
}

void AIOne(Entity player) {
	//if(player.position>t)
}

bool below = true;
void Entity::wonV2(Entity player,Entity* enemies, int enemyCount) {
	for (int i = 0; i < enemyCount; i++) {
		if (enemies[i].position.y <= -6) {
			below = false;
		}
	 
	}
	if (below) {
		player.winner = true;
	}
	else {
		player.winner = false;
	}
	
}
bool Entity::CheckCollision(Entity other)
{
	if (isStatic == true) return false;
	if (isActive == false || other.isActive == false) return false;

	float xdist = fabs(position.x - other.position.x) - ((width + other.width) / 2.0f);
	float ydist = fabs(position.y - other.position.y) - ((height + other.height) / 2.0f);

	if (xdist < 0 && ydist < 0)
	{
		if (entityType == PLAYER && other.entityType == COIN)
		{
			other.isActive = false;
		}

		return true;
	}

	return false;
}
int deleting;
bool DefeatedALL = true;


bool Entity::won(Entity* enemies, int enemyCount) {
	if (this->enemieskilled > 3) {
	 
		return 3;
	}
	for (int i = 0; i < enemyCount; i++) {
		if (enemies[i].position.y > -6) {
			
			DefeatedALL = false;

		}

	}
	if (DefeatedALL) {
		glClearColor(0.07f, 0.5f, 0.5f, 1.0f);
		return true;
		 
	}
	else
	{
		return false;
	}	
	return false;

	
}
int returning;
int Entity::EnemyonPlayer(Entity player, Entity* enemies, int enemyCount) {
	if (won(enemies, enemyCount)) {
		glClearColor(1.0f, 0.6f, 0.0f, 1.0f);
		return 3;
	}
	for (int i = 0; i < enemyCount; i++) {
		if ((player.position.x + 0.6 > enemies[i].position.x) && (player.position.x -0.6 < enemies[i].position.x) ) {
			 
			if (player.position.y > enemies[i].position.y + 0.5 && player.position.y < enemies[i].position.y + 1.5) {
				//glClearColor(0.0f, 1.0f, 0.0f, 1.0f);
				player.enemieskilled += 1;
				glClearColor(1.0f, 0.6f, 0.9f, 1.0f);
				enemies[i].position = glm::vec3(-100, -100, 0);
				return 3;
					 
;			 
		 
			}
			else if (player.position.y > enemies[i].position.y + 1.5) {
			
			}

 
			else {
				glClearColor(1.0f, 0.1f, 0.1f, 0.5f);
				returning =  2;
		
				
				 
			}
		}
		 
		 
	}
	
	return returning;
}

void Entity::CheckCollisionsY(Entity* objects, int objectCount)
{
	for (int i = 0; i < objectCount; i++)
	{
		Entity object = objects[i];

		if (CheckCollision(object))
		{
			float ydist = fabs(position.y - object.position.y);
			float penetrationY = fabs(ydist - (height / 2) - (object.height / 2));
			if (velocity.y > 0) {
				position.y -= penetrationY;
				velocity.y = 0;
				collidedTop = true;
			}
			else if (velocity.y < 0) {
				position.y += penetrationY;
				velocity.y = 0;
				collidedBottom = true;
			}
		}
		
		if (object.entityType==ENEMY) {
			
			//	glClearColor(1.f, 0.0f, 0.0f, 1.0f);
				//objects[i].position.x = 10;
			}


		 
	 

	}

}

void Entity::CheckCollisionsX(Entity* objects, int objectCount)
{
	for (int i = 0; i < objectCount; i++)
	{
		Entity object = objects[i];

		if (CheckCollision(object))
		{
			float xdist = fabs(position.x - object.position.x);
			float penetrationX = fabs(xdist - (width / 2) - (object.width / 2));
			if (velocity.x > 0) {
				position.x -= penetrationX;
				velocity.x = 0;
				collidedRight = true;
			}
			else if (velocity.x < 0) {
				position.x += penetrationX;
				velocity.x = 0;
				collidedLeft = true;
			}
		}
	}
}


void Entity::Jump()
{
	if (collidedBottom)
	{
		velocity.y = 5.0f;
	}
}




void Entity::Update(float deltaTime, Entity* objects, int objectCount, Entity* enemies, int enemyCount)
{
	collidedTop = false;
	collidedBottom = false;
	collidedLeft = false;
	collidedRight = false;
	enemies;

	velocity += acceleration * deltaTime;

	position.y += velocity.y * deltaTime;        // Move on Y
	CheckCollisionsY(objects, objectCount);    // Fix if needed on ground
	//CheckCollisionsY(enemies, enemyCount);    // Fix if needed on enemies


	position.x += velocity.x * deltaTime;        // Move on X
	CheckCollisionsX(objects, objectCount);    // Fix if needed on ground
//	CheckCollisionsX(enemies, enemyCount);    // Fix if needed on enemies
	if (this->entityType ==PLAYER) {
		
		CheckCollisionsY(enemies, enemyCount);    // Fix if needed on enemies
		CheckCollisionsX(enemies, enemyCount);    // Fix if needed on enemies
	}
 
}



void Entity::Render(ShaderProgram* program) {
	glm::mat4 modelMatrix = glm::mat4(1.0f);
	modelMatrix = glm::translate(modelMatrix, position);
	program->SetModelMatrix(modelMatrix);

	if (this->entityType!=TITLE) {
		float vertices[] = { -0.5, -0.5, 0.5, -0.5, 0.5, 0.5, -0.5, -0.5, 0.5, 0.5, -0.5, 0.5 };
		float texCoords[] = { 0.0, 1.0, 1.0, 1.0, 1.0, 0.0, 0.0, 1.0, 1.0, 0.0, 0.0, 0.0 };
		glBindTexture(GL_TEXTURE_2D, textureID);

		glVertexAttribPointer(program->positionAttribute, 2, GL_FLOAT, false, 0, vertices);
		glEnableVertexAttribArray(program->positionAttribute);

		glVertexAttribPointer(program->texCoordAttribute, 2, GL_FLOAT, false, 0, texCoords);
		glEnableVertexAttribArray(program->texCoordAttribute);

		glDrawArrays(GL_TRIANGLES, 0, 6);

		glDisableVertexAttribArray(program->positionAttribute);
		glDisableVertexAttribArray(program->texCoordAttribute);

	}
	else {
		glClearColor(0.0f, 0.7f, 0.7f, 1.0f);
		float vertices[] = { -3.5, -0.50, 3.5, -0.50, 3.5, 0.50, -3.5, -0.50, 3.5, 0.50, -3.5, 0.50 };
		float texCoords[] = { 0.0, 1.0, 1.0, 1.0, 1.0, 0.0, 0.0, 1.0, 1.0, 0.0, 0.0, 0.0 };
		glBindTexture(GL_TEXTURE_2D, textureID);

		glVertexAttribPointer(program->positionAttribute, 2, GL_FLOAT, false, 0, vertices);
		glEnableVertexAttribArray(program->positionAttribute);

		glVertexAttribPointer(program->texCoordAttribute, 2, GL_FLOAT, false, 0, texCoords);
		glEnableVertexAttribArray(program->texCoordAttribute);

		glDrawArrays(GL_TRIANGLES, 0, 6);

		glDisableVertexAttribArray(program->positionAttribute);
		glDisableVertexAttribArray(program->texCoordAttribute);
	}



}

